PROCESS_NAME = 'League of Legends.exe'

oObjectManager = 0x187AEFC #0x24B80A8
oObjectMapRoot = 40
oObjectMapNodeNetId = 16
oObjectMapNodeObject = 20
 
OBJECT_SIZE = 0x3700
oObjectAbilityPower = 0x1740 
oObjectArmor = 0x12AC 
oObjectAtkRange = 0x1394
oObjectAtkSpeedMulti = 0x1348
oObjectBaseAtk = 0x134C
oObjectBonusAtk = 0x12C4
oObjectHealth = 0xE74 
oObjectMaxHealth = 0xE84
oObjectLevel = 0x3384
oObjectMagicRes = 0x12B4 
oObjectMana = 0x29C 
oObjectPos = 0x01DC 
oObjectTeam = 0x34 
oObjectTargetable = 0xD04 
oObjectVisibility = 0x274 
oObjectName = 0x2BA4# 0x2D90
oObjectNetworkID = 0xB4 
oObjectSizeMultiplier = 0x12D4
oObjectSpellBook = 0x2330
oObjectSpawnCount = 0x2A0
oObjectSpellBookArray = 0x488
oObjectBuffManager = 0x2178
oObjectBuffManagerEntriesStart = oObjectBuffManager + 0x10
oObjectBuffManagerEntriesEnd = oObjectBuffManager + 0x14
 
SPELL_SIZE = 0x30
oSpellSlotLevel = 0x1C
oSpellSlotCooldownExpire = 0x0288
 
BUFF_SIZE = 0x78
oBuffInfo = 0x8
oBuffCount = 0x24
oBuffEndTime = 0x10
oBuffInfoName = 0x4
 
oObjectX = oObjectPos
oObjectZ = oObjectPos + 0x4
oObjectY = oObjectPos + 0x8
 

#oZoomClass = 0x30F080C
oLocalPlayer = 0x3117E0C# 0x31090e8
oViewProjMatrices = 0x31479B8#0x31340C8 
oRenderer = 0x314A8A4#0x3136fc8
oRendererWidth = 0x8
oRendererHeight = 0xc
oGameTime = 0x3110E24 #0x31001D0 [<league of legends.exe> + 0x3109fac]