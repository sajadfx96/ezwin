PROCESS_NAME = 'League of Legends.exe'

oObjectManager = 0x1879830
oObjectMapRoot = 0x28
oObjectMapNodeNetId = 0x10
oObjectMapNodeObject = 0x14
 
OBJECT_SIZE = 0x3400
oObjectAbilityPower = 0x1788 
oObjectArmor = 0x12E4 
oObjectAtkRange = 0x1304
oObjectAtkSpeedMulti = 0x12B8
oObjectBaseAtk = 0x12BC
oObjectBonusAtk = 0x1234
oObjectHealth = 0xDB4 
oObjectMaxHealth = oObjectHealth + 0x10
oObjectLevel = 0x33A4
oObjectMagicRes = 0x12EC 
oObjectMana = 0x2B4 
oObjectPos = 0x1F4 
oObjectTeam = 0x4C 
oObjectTargetable = 0xD1C 
oObjectVisibility = 0x28C 
oObjectName = 0x2BE4
oObjectNetworkID = 0xCC 
oObjectSizeMultiplier = 0x12D4
oObjectSpellBook = 0x27E4
oObjectSpawnCount = 0x2A0
oObjectSpellBookArray = 0x488
oObjectBuffManager = 0x21B8
oObjectBuffManagerEntriesStart = oObjectBuffManager + 0x10
oObjectBuffManagerEntriesEnd = oObjectBuffManager + 0x14
 
SPELL_SIZE = 0x30
oSpellSlotLevel = 0x20
oSpellSlotCooldownExpire = 0x28
 
BUFF_SIZE = 0x78
oBuffInfo = 0x8
oBuffCount = 0x74
oBuffEndTime = 0x10
oBuffInfoName = 0x8
 
oObjectX = oObjectPos
oObjectZ = oObjectPos + 0x4
oObjectY = oObjectPos + 0x8
 

#oZoomClass = 0x30F080C
oLocalPlayer = 0x31168d4
oViewProjMatrices = 0x3140f40
oRenderer = 0x3143de0
oRendererWidth = 0xC
oRendererHeight = 0x10
oGameTime = 0x310df78