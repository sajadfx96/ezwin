import time
import mouse
import keyboard
from world import find_game_time

LETHAL_TEMPO = 'ASSETS/Perks/Styles/Precision/LethalTempo/LethalTempo.lua'
HAIL_OF_BLADES = 'ASSETS/Perks/Styles/Domination/HailOfBlades/HailOfBladesBuff.lua'
#LETHAL_TEMPO_STACKS_UNCAPPED_RANGED = 30.
#LETHAL_TEMPO_STACKS_UNCAPPED_MELEE = 60.


class OrbWalker:
    def __init__(self, mem):
        self.mem = mem
        game_time = find_game_time(self.mem)
        self.can_attack_time = game_time
        self.can_move_time = game_time

    @staticmethod
    def get_attack_time(champion, attack_speed_base, attack_speed_ratio, attack_speed_cap):
        total_attack_speed = min(attack_speed_cap, (champion.attack_speed_multiplier - 1) * attack_speed_ratio + attack_speed_base)
        return 1. / total_attack_speed
 
    def calc_tempo(champion, type):
        lvl = champion.level
        if lvl < 3:
            LETHAL_TEMPO_STACKS_UNCAPPED_RANGED = 30.
            LETHAL_TEMPO_STACKS_UNCAPPED_MELEE = 60.
            if type == "ranged":
                return LETHAL_TEMPO_STACKS_UNCAPPED_RANGED
            else:
                return LETHAL_TEMPO_STACKS_UNCAPPED_MELEE
        if lvl >= 3 and lvl < 6:
            LETHAL_TEMPO_STACKS_UNCAPPED_RANGED = 36.
            LETHAL_TEMPO_STACKS_UNCAPPED_MELEE = 66.
            if type == "ranged":
                return LETHAL_TEMPO_STACKS_UNCAPPED_RANGED
            else:
                return LETHAL_TEMPO_STACKS_UNCAPPED_MELEE
        if lvl >= 6 and lvl < 9:
            LETHAL_TEMPO_STACKS_UNCAPPED_RANGED = 42.
            LETHAL_TEMPO_STACKS_UNCAPPED_MELEE = 72.
            if type == "ranged":
                return LETHAL_TEMPO_STACKS_UNCAPPED_RANGED
            else:
                return LETHAL_TEMPO_STACKS_UNCAPPED_MELEE
        if lvl >= 9 and lvl < 12:
            LETHAL_TEMPO_STACKS_UNCAPPED_RANGED = 48.
            LETHAL_TEMPO_STACKS_UNCAPPED_MELEE = 78.
            if type == "ranged":
                return LETHAL_TEMPO_STACKS_UNCAPPED_RANGED
            else:
                return LETHAL_TEMPO_STACKS_UNCAPPED_MELEE
        if lvl >= 12 and lvl < 15:
            LETHAL_TEMPO_STACKS_UNCAPPED_RANGED = 54.
            LETHAL_TEMPO_STACKS_UNCAPPED_MELEE = 84.
            if type == "ranged":
                return LETHAL_TEMPO_STACKS_UNCAPPED_RANGED
            else:
                return LETHAL_TEMPO_STACKS_UNCAPPED_MELEE
        if lvl >= 15:
            LETHAL_TEMPO_STACKS_UNCAPPED_RANGED = 54.
            LETHAL_TEMPO_STACKS_UNCAPPED_MELEE = 90.
            if type == "ranged":
                return LETHAL_TEMPO_STACKS_UNCAPPED_RANGED
            else:
                return LETHAL_TEMPO_STACKS_UNCAPPED_MELEE
        
    @staticmethod
    def get_windup_time(champion, attack_speed_base, attack_speed_ratio, windup_percent, windup_modifier, attack_speed_cap):
        # More information at https://leagueoflegends.fandom.com/wiki/Basic_attack#Attack_speed
        attack_time = OrbWalker.get_attack_time(champion, attack_speed_base, attack_speed_ratio, attack_speed_cap)
        base_windup_time = (1 / attack_speed_base) * windup_percent
        windup_time = base_windup_time + ((attack_time * windup_percent) - base_windup_time) * windup_modifier
        if champion.name == "Jinx":
            windup_time = windup_time - 0.2
        if champion.name == "Kayle":
            windup_time = windup_time - 0.5
        return windup_time

    @staticmethod
    def get_attack_speed_cap(stats, champion, game_time):
        uncapped = False
        lethal_tempo_buffs =  [buff for buff in champion.buffs[LETHAL_TEMPO] if buff.end_time > game_time]
        assert len(lethal_tempo_buffs) <= 1
        if lethal_tempo_buffs:
            lethal_tempo, = lethal_tempo_buffs
            if stats.is_melee(champion.name):
                uncapped |= lethal_tempo.count >= float(OrbWalker.calc_tempo(champion, "melee"))
            else:
                uncapped |= lethal_tempo.count >= float(OrbWalker.calc_tempo(champion, "ranged"))
        uncapped |= any([buff.end_time > game_time for buff in champion.buffs[HAIL_OF_BLADES]])
        if uncapped:
            return 90.
        return 2.5
 
    def walk(self, stats, champion, x, y, game_time):
        mouse.press(mouse.MIDDLE)
        attack_speed_cap = OrbWalker.get_attack_speed_cap(stats, champion, game_time)
        if x is not None and y is not None and self.can_attack_time < game_time:
            stored_x, stored_y = mouse.get_position()
            mouse.move(int(x), int(y))
            mouse.right_click()
            game_time = find_game_time(self.mem)
            attack_speed_base, attack_speed_ratio = stats.get_attack_speed(champion.name)
            windup_percent, windup_modifier = stats.get_windup(champion.name)
            self.can_attack_time = game_time + OrbWalker.get_attack_time(champion, attack_speed_base, attack_speed_ratio, attack_speed_cap)
            self.can_move_time = game_time + OrbWalker.get_windup_time(champion, attack_speed_base, attack_speed_ratio, windup_percent, windup_modifier, attack_speed_cap)
            time.sleep(0.05)
            mouse.move(stored_x, stored_y)
        #    mouse.right_click()
          #  print(f"({stored_x},{stored_y}) ({x},{y})")
        elif self.can_move_time < game_time:
            mouse.right_click()
            MOVE_CLICK_DELAY = 0.05
            self.can_move_time = game_time + MOVE_CLICK_DELAY
        mouse.release(mouse.MIDDLE)

    def cast(self, x, y):
        mouse.press(mouse.MIDDLE)
        if x is not None and y is not None:
            stored_x, stored_y = mouse.get_position()
            mouse.move(int(x), int(y))
            keyboard.press_and_release('q')
            time.sleep(0.01)
            game_time = find_game_time(self.mem)
            self.can_attack_time = game_time + 0.25
            self.can_move_time = game_time + 0.25
            mouse.move(stored_x, stored_y)
        mouse.release(mouse.MIDDLE)
